# ParkMeOwner
This application is for parking owner registration.
The Parking owner will add-
 1. Parking Location and name.
 2. Pictures of Interior and Exterior of parking.
 3. Document of parking.
 4. Owner Details like email and mobile number.
 
 They can set there price and slots availabe for fourwheeler and two wheeler.
 
 After booked order from user side Owner can-
 
  1. Confirm the order and after confirmation, otp will needed for checkin and price calculation will started after checkin only and upto checkout.
  2. Cancel the order.(If he/she is not available)
 
  Bill will be generated according to spent time of vehicle in parking.
    
