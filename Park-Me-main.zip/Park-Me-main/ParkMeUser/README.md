# ParkMeUser
In this application User can book there parking slots nearer to them.
They can compare the prices of different parking areas makes price effective parking.
Price calculation will start only after sharing otp given in the app which is needed for checkin and upto checkout.
Bill will be calculated by app after checkout.
User can see bookings history.
